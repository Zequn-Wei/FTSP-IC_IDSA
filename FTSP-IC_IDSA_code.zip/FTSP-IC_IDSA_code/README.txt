We provide a execution file 'FTSP-IC', which is compiled in Linux environment with g++ and optimization flag '-O3'.
You could execute the program directly by inputing 4 parameters: 
-i: the path to instance
--seed: the seed
-r: the file of execution results (For each improvement, first column is fitness value, second column is the time to get the related fitness value)
-s: the file of output solution (Detail paths)
-t: running time (in seconds)

Here is an example to run 'burma14.tsp_3_1001_1003_2_inc_0.9.txt' by setting seed as 0, execution time as 10 seconds, printing the results in 'Results.txt' and the best found solution in 'Solution.txt':

./FTSP-IC -i Benchmark/burma14.tsp_3_1001_1003_2_inc_0.9.txt --seed 0 -r Results.txt -s Solution.txt -t 10

